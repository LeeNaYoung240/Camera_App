#include<opencv2/opencv.hpp>
#include<iostream>
#include <string>
using namespace cv;
using namespace cv::ml;
using namespace std;
void on_mouse(int event, int x, int y, int flags, void* userdata);
int main()
{
    Mat cur(400, 400, CV_8UC1, Scalar(0));

    imshow("cur", cur);
    setMouseCallback("cur", on_mouse, (void*)&cur);
    int num = 0;
    while (true) {
        int c = waitKey(0);
        if (c == 27)break;
        else if (c == ' ') {
            string str = format("X_%d.jpg", num);
            num++;
            imwrite(str, cur);
            if (num == 100) {
                num = 0;
            }
            cur.setTo(0);
            imshow("cur", cur);
        }
    }
    return 0;
}
Point ptPrev(-1, -1);
void on_mouse(int event, int x, int y, int flags, void* userdata)
{
    Mat cur = *(Mat*)userdata;
    if (event == EVENT_LBUTTONDOWN) {
        ptPrev = Point(x, y);
    }
    else if (event == EVENT_LBUTTONUP) {
        ptPrev = Point(-1, -1);
    }
    else if ((event == EVENT_MOUSEMOVE) && (flags & EVENT_FLAG_LBUTTON))
    {
        line(cur, ptPrev, Point(x, y), Scalar::all(255), 40, LINE_AA, 0);
        ptPrev = Point(x, y);
        imshow("cur", cur);
    }
}